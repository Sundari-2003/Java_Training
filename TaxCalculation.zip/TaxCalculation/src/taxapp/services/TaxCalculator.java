package taxapp.services;

public interface TaxCalculator<T> {
    double calculateTax(T item);
}



//package taxapp.services;
//
//public interface TaxCalculator<T> {
//    void calculateTax(T item);
//}
