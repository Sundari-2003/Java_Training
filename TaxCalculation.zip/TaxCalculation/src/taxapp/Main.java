package taxapp;

import taxapp.ui.WelcomeScreen;

public class Main {
    public static void main(String[] args) {
        WelcomeScreen welcomeScreen = new WelcomeScreen();
        welcomeScreen.show();
    }
}
